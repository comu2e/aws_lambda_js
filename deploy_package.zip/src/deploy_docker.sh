# Dockerfileからイメージの作成
 docker build -t deploypackage src/. -f .docker/Dockerfile
# 実行
docker run --rm -v "$PWD":/var/task deploypackage:latest

aws lambda create-function --role {ARN=`aws iam list-roles --query "Roles[?RoleName== '$1'].[RoleName, Arn]" | jq -r '.[][1]'`} --function-name $1 --zip-file fileb://deploy_package.zip --handler index.handler --runtime nodejs12.x
