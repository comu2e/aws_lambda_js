
# Execute method

Run locally
```
$ sh .bin/local.sh
```

Run locally as api
Run locally

```
$ sh .bin/api.sh
```
```
$ curl -d '{"aaa": "bbb"}' http://127.0.0.1:9001/2015-03-31/functions/index/invocations
```
# Thanks to below article.
Reference is below.

https://zenn.dev/nekoniki/articles/b1f94bfbb28e29

https://hub.docker.com/r/lambci/lambda/