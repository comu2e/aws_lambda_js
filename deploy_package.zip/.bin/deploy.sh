zip -r9 deploy_package.zip .
aws iam create-role --role-name testFunction2 --assume-role-policy-document file://role.json
# aws lambda create-function --role 【ARNの値】 --function-name testFunction2 --zip-file fileb://deploy_package.zip --handler index.handler --runtime nodejs12.x
